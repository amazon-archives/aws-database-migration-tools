\i create-table.sql
\i create-index.sql